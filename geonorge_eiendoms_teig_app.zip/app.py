from flask import Flask, request, render_template, send_file
import requests
import time
import tempfile
import os
import io
import zipfile
import json
import folium
from shapely.geometry import shape, mapping, Polygon, MultiPolygon, Point
from shapely.ops import transform as shp_transform
import gpxpy, gpxpy.gpx
from fastkml import kml
from pyproj import Transformer

app = Flask(__name__)

# Geonorge Nedlasting API
DATASET_UUID = "74340c24-1c8a-4454-b813-bfe498e80f16"  # Matrikkelen – Eiendomskart Teig
BASE = "https://nedlasting.geonorge.no"
ORDER_V2 = f"{BASE}/api/v2/order"
ORDER_STATUS_V2 = f"{BASE}/api/v2/order"
DOWNLOAD_V2 = f"{BASE}/api/v2/download/order"
CAP_V2 = f"{BASE}/api/v2/capabilities/{DATASET_UUID}"
FORMAT_V2 = f"{BASE}/api/v2/codelists/format/{DATASET_UUID}"
PROJ_V2 = f"{BASE}/api/v2/codelists/projection/{DATASET_UUID}"

# Geonorge Adresse-API (for enkel geokoding)
ADRESSE_API = "https://ws.geonorge.no/adresser/v1/sok"

def geocode_adresse(adresse: str):
    r = requests.get(ADRESSE_API, params={"sok": adresse, "treffPerSide": 1})
    r.raise_for_status()
    data = r.json()
    if not data.get("adresser"):
        return None
    a = data["adresser"][0]
    if "representasjonspunkt" in a and a["representasjonspunkt"]:
        lon = a["representasjonspunkt"]["lon"]
        lat = a["representasjonspunkt"]["lat"]
        crs = 4326
    elif "punkt" in a and a["punkt"]:
        epsg = int(a["punkt"]["epsg"])
        E, N = [float(x) for x in a["punkt"]["koordinater"].split(",")]
        trans = Transformer.from_crs(epsg, 4326, always_xy=True)
        lon, lat = trans.transform(E, N)
        crs = 4326
    else:
        return None
    return {"lon": float(lon), "lat": float(lat), "crs": crs}

def build_clip_polygon_from_point(lon, lat, size_m=100):
    """
    Lager et kvadratisk polygon (buffer) rundt punktet i EPSG:25833 for bestilling.
    size_m er halvsiden (100 m => 200 x 200 m).
    Returnerer (koordinatstreng, koordinatsystemkode).
    """
    to_utm = Transformer.from_crs(4326, 25833, always_xy=True)
    x, y = to_utm.transform(lon, lat)
    half = float(size_m)
    poly_utm = Polygon([(x-half, y-half), (x+half, y-half), (x+half, y+half), (x-half, y+half), (x-half, y-half)])
    coords = " ".join([f"{round(px,3)} {round(py,3)}" for (px, py) in list(poly_utm.exterior.coords)])
    return coords, "25833"

def post_polygon_order(email, coords_str, coord_sys="25833", format_name="GeoJSON", projection_code="4326"):
    payload = {
        "email": email,
        "orderLines": [
            {
                "metadataUuid": DATASET_UUID,
                "areas": [
                    {"code": "Kart", "name": "Valgt fra kart", "type": "polygon"}
                ],
                "projections": [
                    {"code": str(projection_code)}
                ],
                "formats": [
                    {"name": format_name}
                ],
                "coordinates": coords_str,
                "coordinateSystem": coord_sys
            }
        ]
    }
    r = requests.post(ORDER_V2, json=payload, timeout=60)
    if r.status_code != 200:
        raise Exception(f"Bestilling feilet ({r.status_code}): {r.text[:300]}")
    return r.json()

def poll_order(reference_number, timeout_s=180, interval_s=5):
    end = time.time() + timeout_s
    last = None
    while time.time() < end:
        r = requests.get(f"{ORDER_STATUS_V2}/{reference_number}", timeout=30)
        if r.status_code != 200:
            time.sleep(interval_s)
            continue
        info = r.json()
        files = info.get("files", [])
        ready = [f for f in files if f.get("status") == "ReadyForDownload" and f.get("downloadUrl")]
        if ready:
            return info
        last = info
        time.sleep(interval_s)
    return last or {"files": []}

def download_first_file(order_info):
    files = order_info.get("files", [])
    preferred = None
    for f in files:
        if f.get("downloadUrl") and ("geojson" in f.get("name","").lower() or f.get("format","").lower().startswith("geojson")):
            preferred = f
            break
    if not preferred:
        preferred = next((f for f in files if f.get("downloadUrl")), None)
    if not preferred:
        raise Exception("Ingen nedlastingsfil klar ennå (status=WaitingForProcessing). Prøv igjen senere.")
    url = preferred["downloadUrl"]
    rr = requests.get(url, timeout=120)
    rr.raise_for_status()
    return rr.content, preferred.get("name","download.zip")

def unpack_geojson_from_zip(zip_bytes):
    zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
    geojson_bytes = None
    gml_bytes = None
    out_names = []
    for name in zf.namelist():
        lower = name.lower()
        if lower.endswith(".geojson") or lower.endswith(".json"):
            geojson_bytes = zf.read(name)
            out_names.append(name)
            break
        elif lower.endswith(".gml"):
            gml_bytes = zf.read(name)
            out_names.append(name)
    if geojson_bytes:
        return "geojson", geojson_bytes, out_names
    if gml_bytes:
        return "gml", gml_bytes, out_names
    raise Exception("Finner ikke GeoJSON/GML i nedlastet zip.")

def folium_map_from_geojson_bytes(geojson_bytes):
    data = json.loads(geojson_bytes.decode("utf-8"))
    if not data.get("features"):
        return "<p>Ingen teiger returnert.</p>"
    geom = shape(data["features"][0]["geometry"])
    minx, miny, maxx, maxy = geom.bounds
    center = [(miny+maxy)/2.0, (minx+maxx)/2.0]
    m = folium.Map(location=center, zoom_start=16)
    folium.GeoJson(data, name="Eiendomsteig").add_to(m)
    html_path = tempfile.NamedTemporaryFile(delete=False, suffix=".html").name
    m.save(html_path)
    with open(html_path, "r", encoding="utf-8") as f:
        return f.read()

def geojson_to_gpx(geojson_bytes):
    data = json.loads(geojson_bytes.decode("utf-8"))
    gpx = gpxpy.gpx.GPX()
    for feat in data.get("features", []):
        geom = shape(feat["geometry"])
        polys = []
        if isinstance(geom, Polygon):
            polys = [geom]
        elif isinstance(geom, MultiPolygon):
            polys = list(geom.geoms)
        for poly in polys:
            seg = gpxpy.gpx.GPXTrackSegment()
            for x, y in poly.exterior.coords:
                seg.points.append(gpxpy.gpx.GPXTrackPoint(y, x))
            gpx.tracks.append(gpxpy.gpx.GPXTrack(segments=[seg]))
    return gpx.to_xml()

def geojson_to_kml(geojson_bytes):
    data = json.loads(geojson_bytes.decode("utf-8"))
    k = kml.KML()
    ns = "{http://www.opengis.net/kml/2.2}"
    doc = kml.Document(ns, "1", "Eiendomsteig", "Fra Geonorge Nedlasting API")
    k.append(doc)
    for feat in data.get("features", []):
        geom = shape(feat["geometry"])
        pm = kml.Placemark(ns, None, "Teig", "")
        pm.geometry = geom
        doc.append(pm)
    return k.to_string(prettyprint=True)

@app.route("/", methods=["GET", "POST"])
def index():
    map_html = None
    message = None
    download_paths = {}
    if request.method == "POST":
        adresse = request.form.get("adresse","").strip()
        kommunenr = request.form.get("kommunenr","").strip()
        email = request.form.get("email","").strip()
        try:
            if not email:
                return "E-post er påkrevd for polygon-uttak (krav i Geonorge API). Gå tilbake og fyll inn e-post."
            if adresse:
                geo = geocode_adresse(adresse)
                if not geo:
                    return "Fant ikke adresse i Geonorge. Sjekk stavemåte."
                coords_str, coord_sys = build_clip_polygon_from_point(geo["lon"], geo["lat"], size_m=120)
                order = post_polygon_order(email=email, coords_str=coords_str, coord_sys=coord_sys, format_name="GeoJSON", projection_code="4326")
            else:
                if not (kommunenr and kommunenr.isdigit() and len(kommunenr) == 4):
                    return "Oppgi enten adresse, eller korrekt kommunenummer (4 siffer)."
                payload = {
                    "email": email,
                    "orderLines": [{
                        "metadataUuid": DATASET_UUID,
                        "areas": [{"code": kommunenr, "type": "kommune", "name": kommunenr}],
                        "projections": [{"code":"4326"}],
                        "formats": [{"name":"GeoJSON"}]
                    }]
                }
                r = requests.post(ORDER_V2, json=payload, timeout=60)
                if r.status_code != 200:
                    raise Exception(f"Bestilling feilet ({r.status_code}): {r.text[:300]}")
                order = r.json()

            ref = order.get("referenceNumber")
            if not ref:
                return f"Bestilling mottatt, men ingen referanse. Rådata: {order}"
            info = poll_order(ref, timeout_s=240, interval_s=6)
            zip_bytes, zip_name = download_first_file(info)
            kind, content_bytes, names = unpack_geojson_from_zip(zip_bytes)
            if kind == "gml":
                return "Fikk GML tilbake. For enkelhets skyld bestill på nytt med format=GeoJSON, eller konverter GML i QGIS."
            gpx_xml = geojson_to_gpx(content_bytes)
            kml_xml = geojson_to_kml(content_bytes)
            gpx_path = tempfile.NamedTemporaryFile(delete=False, suffix=".gpx").name
            kml_path = tempfile.NamedTemporaryFile(delete=False, suffix=".kml").name
            with open(gpx_path, "w", encoding="utf-8") as f:
                f.write(gpx_xml)
            with open(kml_path, "w", encoding="utf-8") as f:
                f.write(kml_xml)
            map_html = folium_map_from_geojson_bytes(content_bytes)
            download_paths = {"gpx": "/nedlast/" + os.path.basename(gpx_path), "kml": "/nedlast/" + os.path.basename(kml_path)}
        except Exception as e:
            message = f"Feil: {e}"
    return render_template("index.html", map_html=map_html, download_paths=download_paths, message=message)

@app.route("/nedlast/<path:filename>")
def nedlast(filename):
    return send_file(f"/tmp/{filename}", as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True)